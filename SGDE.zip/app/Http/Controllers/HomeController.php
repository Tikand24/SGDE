<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\HorarioEucaristia;
use App\Feligre;
use Validator;
use App\Http\Controllers\Controller;
use App\MensajesSacerdote;
use App\AvisosParroquiale;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->middleware('auth');
        return view('home');
    }

    public function horarioSemanal($dia)
    {
        try {
            $hoy=$dia;
            if (($dia+1)>7) {
                $manhiana=1;
            }else{
                $manhiana=$dia+1;
            }
            if (($dia+2)>7) {
                $pasadomanhiana=2;
            }else{
                $pasadomanhiana=$dia+2;
            }
            return response()->json([
                'dia1'=>HorarioEucaristia::where('dia_eucaristia_id',$hoy)->where('estado','Activo')->where('semanal','1')->with(['DiasEucaristia','LugarEucaristia'])->get(),
                'dia2'=>HorarioEucaristia::where('dia_eucaristia_id',$manhiana)->where('estado','Activo')->where('semanal','1')->with(['DiasEucaristia','LugarEucaristia'])->get(),
                'dia3'=>HorarioEucaristia::where('dia_eucaristia_id',$pasadomanhiana)->where('estado','Activo')->where('semanal','1')->with(['DiasEucaristia','LugarEucaristia'])->get()
            ]);
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }
    public function avisosParroquiales()
    {
        try {
            return response()->json([
                'avisos'=>AvisosParroquiale::orderBy('updated_at','desc')->limit(3)->get()
            ]);
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }
    public function allAvisosParroquiales()
    {
        try {
            return response()->json([
                'avisos'=>AvisosParroquiale::orderBy('updated_at','desc')->get()
            ]);
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }
    public function allHorario()
    {
        try {
            $horarios = HorarioEucaristia::where('estado','Activo')->where('semanal','1')->groupBy('dia_eucaristia_id')->orderBy('dia_eucaristia_id','asc')->with(['DiasEucaristia','LugarEucaristia'])->get();
            $horarioFinal = [];
            foreach ($horarios as $hora) {
                $horarioFinal[] = [
                    'dia' => $hora->DiasEucaristia->dia_semana, 
                    'horario' => HorarioEucaristia::where('dia_eucaristia_id',$hora->dia_eucaristia_id)->where('estado','Activo')->where('semanal','1')->orderBy('hora_eucaristia','asc')->with(['DiasEucaristia','LugarEucaristia'])->get()
                ];
            }
            return response()->json([
                'horario'=>$horarioFinal
            ]);
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }
    public function guardarFeligres(Request $request)
    {
        try {
            $validador = Validator::make($request->all(), [
                'nombre' => 'required',
                'apellido' => 'required',
                'fecha_nacimiento' => 'required',
                'recibir_notificacion' => 'required',
            ]);
            if ($validador->fails()) {
                return response()->json([
                    'estado' => 'validador',
                    'errors' => $validador->errors(),
                ]);
            }
            $feligres = new Feligre();
            $feligres->nombre = $request->nombre;
            $feligres->apellido = $request->apellido;
            $feligres->fecha_nacimiento = $request->fecha_nacimiento;
            $feligres->email = $request->email;
            $feligres->telefono = $request->telefono;
            $feligres->recibir_notificacion = $request->recibir_notificacion;
            $feligres->save();
            return response()->json([
                'estado' => 'ok',
                'tipo' => 'save'
            ]);
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }
    public function guardarMensajeFeligres(Request $request)
    {
        try {
            $validador = Validator::make($request->all(), [
                'nombre' => 'required',
                'mensaje' => 'required',
                'sacerdote' => 'required',
            ]);
            if ($validador->fails()) {
                return response()->json([
                    'estado' => 'validador',
                    'errors' => $validador->errors(),
                ]);
            }
            $mensajeSacerdote = new MensajesSacerdote();
            $mensajeSacerdote->nombre_feligres = $request->nombre;
            $mensajeSacerdote->sacerdote = $request->sacerdote;
            $mensajeSacerdote->mensaje = $request->mensaje;
            $mensajeSacerdote->save();
            return response()->json([
                'estado' => 'ok',
                'tipo' => 'save'
            ]);
        } catch (Exception $e) {
         return response()->json($e->getMessage());   
        }
    }
}

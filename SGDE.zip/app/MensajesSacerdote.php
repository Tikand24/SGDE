<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MensajesSacerdote extends Model {
	
}

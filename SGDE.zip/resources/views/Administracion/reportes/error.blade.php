<!DOCTYPE html>
<html>
<head>
	<title>Error</title>
</head>
<body>
	<h1>Error al generar el pdf</h1>
	<h1>Verifique que se cuente con el siguiente dato: {{ $mensaje }}</h1>
</body>
</html>
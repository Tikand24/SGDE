
<?php
function mes($mes) {
	$nom = 'nombre mes';
	if ($mes == "January") {
		$nom = "Enero";
	} elseif ($mes == "February") {
		$nom = "Febrero";

	} elseif ($mes == "March") {
		$nom = "Marzo";

	} elseif ($mes == "April") {
		$nom = "Abril";

	} elseif ($mes == "May") {
		$nom = "Mayo";

	} elseif ($mes == "June") {
		$nom = "Junio";

	} elseif ($mes == "July") {
		$nom = "Julio";

	} elseif ($mes == "August") {
		$nom = "Agosto";

	} elseif ($mes == "September") {
		# code...
		$nom = "Septiembre";

	} elseif ($mes == "October") {
		# code...
		$nom = "Octubre";

	} elseif ($mes == "November") {
		# code...
		$nom = "Noviembre";

	} elseif ($mes == "December") {
		# code...
		$nom = "Diciembre";
	}
	return $nom;
}
$date = date_create($datos->fecha_bautismo);
$diaBautizo = date_format($date, "d");
$fecm = date_format($date, "F");
$mesBautizo = mes($fecm);
$yearBautizo = date_format($date, "Y");
$date = date_create($datos->fecha_nacimiento);
$diaNacimiento = date_format($date, "d");
$fecmn = date_format($date, "F");
$mesNacimiento = mes($fecmn);
$yearNacimiento = date_format($date, "Y");
$dhoy = date('d');
$mhoy = mes(strftime('%B'));
$yhoy = date('Y');
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Partida de bautismo <?php echo e(strtoupper($datos->nombre)); ?></title>
	<style>
	*{
		font-family: Helvetica;
		font-size: 14;
	}
	.center-align{
		text-align: center;
	}
	.table{
		width: 100%;
		margin:auto;
	}
	#folio{
		text-align: center;
		margin-top: 5%;
		width: 100%;
	}
	#nombre{
		margin-top: 5%;
	}
	#textoPrinc{
		margin-top: 3%;
		margin-left: 6%;

		text-align: justify;
	}
	.justify-text{
		text-align: justify;
		margin-left: 6%;

	}
	p {
		margin-left: 6%;
	}
	#firma{
		margin-top: 10%;
	}
</style>
</head>
<body>
	<table class="center-align table">
		<tr><th>VICARIA DEL SUMAPAZ</th></tr>
		<tr><th>PARROQUIA DE LA SAGRADA FAMILIA</th></tr>
		<tr><th>FUSAGASUGA, CUNDINAMARCA</th></tr>
		<tr>
			<th>CARRERA 3,17-09 BARRIO BALMORAL</th>
		</tr>
		<tr>
			<th>TELEFONO 8716273 - CEL 3207947407</th>
		</tr>
	</table>
	<pre id="folio">
		<strong>Libro: <?php echo e($datos->libro); ?></strong>     <strong>Folio: <?php echo e($datos->folio); ?></strong>     <strong>Partida: <?php echo e($datos->partida); ?></strong>
	</pre>
	<p id="nombre"><strong><?php echo e(strtoupper($datos->nombre)); ?></strong></p>
	<div id="textoPrinc">
		En la parroquia de la Sagrada Familia de Fusagasugá a los <?php echo e($diaBautizo); ?> días del mes de  <?php echo e($mesBautizo); ?> de  <?php echo e($yearBautizo); ?> Fue bautizado: <strong><?php echo e(strtoupper($datos->nombre)); ?></strong> nacido en <?php echo e($datos->municipio->nom_municipio); ?>-<?php echo e($datos->municipio->departamento->nom_departamento); ?> el  <?php echo e($diaNacimiento); ?> de  <?php echo e($mesNacimiento); ?> de  <?php echo e($yearNacimiento); ?>.
	</div>
	<div class="justify-text">
	<div>
		<strong>Padres:</strong>
		<?php if($datos->nom_padre==null): ?>
		<?php echo e($datos->nom_madre); ?>

		<?php else: ?>
		<?php if($datos->nom_madre==null): ?>
		<?php echo e($datos->nom_padre); ?>

		<?php else: ?>
		<?php echo e($datos->nom_padre); ?> - <?php echo e($datos->nom_madre); ?>

		<?php endif; ?>
		<?php endif; ?>
	</div>
	<div>
		<strong>Abuelos Paternos:</strong>
		<?php if($datos->abuelo_paterno==null): ?>
		<?php echo e($datos->abuela_paterna); ?>

		<?php else: ?>
		<?php if($datos->abuela_paterna==null): ?>
		<?php echo e($datos->abuelo_paterno); ?>

		<?php else: ?>
		<?php echo e($datos->abuelo_paterno); ?> - <?php echo e($datos->abuela_paterna); ?>

		<?php endif; ?>
		<?php endif; ?>
	</div>
	<div>
		<strong>Abuelos Maternos:</strong>
		<?php if($datos->abuelo_materno==null): ?>
		<?php echo e($datos->abuela_materna); ?>

		<?php else: ?>
		<?php if($datos->abuela_materna==null): ?>
		<?php echo e($datos->abuelo_materno); ?>

		<?php else: ?>
		<?php echo e($datos->abuelo_materno); ?> - <?php echo e($datos->abuela_materna); ?>

		<?php endif; ?>
		<?php endif; ?>
	</div>
	<div>
		<strong>Padrinos:</strong>
		<?php if($datos->nom_padrino==null): ?>
		<?php echo e($datos->nom_madrina); ?>

		<?php else: ?>
		<?php if($datos->nom_madrina==null): ?>
		<?php echo e($datos->nom_padrino); ?>

		<?php else: ?>
		<?php echo e($datos->nom_padrino); ?> - <?php echo e($datos->nom_madrina); ?>

		<?php endif; ?>
		<?php endif; ?>
	</div>
	<div>
		<strong>Doy fe:</strong> <?php echo e($datos->CelebranteParroquia->nom_celebrante); ?> - <?php echo e($datos->CelebranteParroquia->cod_cargo_cel); ?>

	</div>
	</div>
	<?php if(count($anotacion)>0): ?>
	<p>
	<?php $__currentLoopData = $anotacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<strong>Anotación:</strong> <?php echo e($anot->Anotacion); ?><br>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</p>
	<?php else: ?>
		<P>Sin nota marginal de matrimonio hasta la fecha</P>
	<?php endif; ?>

	<p>Es fiel copia expedida en Fusagasugá, Cundinamarca a los <?php echo e($dhoy); ?> dias del mes de <?php echo e($mhoy); ?> de <?php echo e($yhoy); ?></p>
	<div id="firma">
		<p><strong><?php echo e($firma->celebrante->nom_celebrante); ?><br>
		<?php echo e($firma->cargo); ?></strong></p>
	</div>
</body>
</html>
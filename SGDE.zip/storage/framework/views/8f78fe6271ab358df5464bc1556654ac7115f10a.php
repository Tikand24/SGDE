<?php
function mes($mes) {
	$nom = 'nombre mes';
	if ($mes == "January") {
		$nom = "Enero";
	} elseif ($mes == "February") {
		$nom = "Febrero";
	} elseif ($mes == "March") {
		$nom = "Marzo";
	} elseif ($mes == "April") {
		$nom = "Abril";
	} elseif ($mes == "May") {
		$nom = "Mayo";
	} elseif ($mes == "June") {
		$nom = "Junio";
	} elseif ($mes == "July") {
		$nom = "Julio";
	} elseif ($mes == "August") {
		$nom = "Agosto";
	} elseif ($mes == "September") {
		# code...
		$nom = "Septiembre";
	} elseif ($mes == "October") {
		# code...
		$nom = "Octubre";
	} elseif ($mes == "November") {
		# code...
		$nom = "Noviembre";
	} elseif ($mes == "December") {
		# code...
		$nom = "Diciembre";
	}
	return $nom;
}
$date = date_create($datos->fecha_matrimonio);
$diaMatrimonio = date_format($date, "d");
$fecm = date_format($date, "F");
$mesMatrimonio = mes($fecm);
$yearMatrimonio = date_format($date, "Y");

$dhoy = date('d');
$mhoy = mes(strftime('%B'));
$yhoy = date('Y');

$fechaBautizoEsposo = date_create($datos->fecha_bautizo_esposo);
$diaBautizoEsposo = date_format($fechaBautizoEsposo, "d");
$mesBautizoEsposo = date_format($fechaBautizoEsposo, "F");
$mesPartidaBautizoEsposo = mes($mesBautizoEsposo);
$yearBautizoEsposo = date_format($fechaBautizoEsposo, "Y");

$fechaBautizoEsposa = date_create($datos->fecha_bautizo_esposa);
$diaBautizoEsposa = date_format($fechaBautizoEsposa, "d");
$mesBautizoEsposa = date_format($fechaBautizoEsposa, "F");
$mesPartidaBautizoEsposa = mes($mesBautizoEsposa);
$yearBautizoEsposa = date_format($fechaBautizoEsposa, "Y");

$padresEsposo="";
if ($datos->padre_esposo != "" && $datos->padre_esposo != null) {
	$padresEsposo=$datos->padre_esposo;
	if ($datos->madre_esposo != "" && $datos->madre_esposo != null) {
		$padresEsposo.=" y ".$datos->madre_esposo;
	}
}else{
	$padresEsposo=$datos->madre_esposo;
}
$padresEsposa="";
if ($datos->padre_esposa != "" && $datos->padre_esposa != null) {
	$padresEsposa=$datos->padre_esposa;
	if ($datos->madre_esposa != "" && $datos->madre_esposa != null) {
		$padresEsposa.=" y ".$datos->madre_esposa;
	}
}else{
	$padresEsposa=$datos->madre_esposa;
}
$testigos="";
if ($datos->padrino != "" && $datos->padrino != null) {
	$testigos=$datos->padrino;
	if ($datos->madrina != "" && $datos->madrina != null) {
		$testigos.=" y ".$datos->madrina;
	}
}else{
	$testigos=$datos->madrina;
}

?>
<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>Partida de bautismo <?php echo e($datos->nombre); ?></title>
		<style>
		*{
			font-family: Helvetica;
			font-size: 14;
		}
		.center-align{
			text-align: center;
		}
		.table{
			width: 100%;
			margin:auto;
		}
		#folio{
			text-align: center;
			margin-top: 5%;
			width: 100%;
		}
		#nombre{
			margin-top: 5%;
		}
		#textoPrinc{
			margin-top: 3%;
			margin-left: 6%;
			text-align: justify;
		}
		.justify-text{
			text-align: justify;
			margin-left: 6%;
		}
		p {
			margin-left: 6%;
		}
		#firma{
			margin-top: 10%;
		}
		</style>
	</head>
	<body>
		<table class="center-align table">
			<tr><th>VICARIA DEL SUMAPAZ</th></tr>
			<tr><th>PARROQUIA DE LA SAGRADA FAMILIA</th></tr>
			<tr><th>FUSAGASUGA, CUNDINAMARCA</th></tr>
			<tr>
				<th>CARRERA 3,17-09 BARRIO BALMORAL</th>
			</tr>
			<tr>
				<th>TELEFONO 8716273 - CEL 3207947407</th>
			</tr>
		</table>
		<pre id="folio">
			<strong>Libro: <?php echo e($datos->libro); ?></strong>     <strong>Folio: <?php echo e($datos->folio); ?></strong>     <strong>Partida: <?php echo e($datos->partida); ?></strong>
		</pre>
		<p id="nombre"><strong><?php echo e($datos->esposo); ?></strong><br><strong><?php echo e($datos->esposa); ?></strong></p>
		<div id="textoPrinc">
			En la Parroquia de la Sagrada Familia de Fusagasugá, a 
			<?php echo e($diaMatrimonio); ?> de 
			<?php echo e($mesMatrimonio); ?> de 
			<?php echo e($yearMatrimonio); ?>, El padre: 
			<?php echo e($datos->Celebrante->Celebrante->nom_celebrante); ?>, presenció el matrimonio que contrajo: 
			<?php echo e($datos->esposo); ?>, hijo de 
			<?php echo e($padresEsposo); ?>, bautizado en la 
			<?php echo e($datos->ParroquiaBautizado->nombre); ?> de 
			<?php echo e($datos->ParroquiaBautizado->Municipio->nom_municipio); ?> - 
			<?php echo e($datos->ParroquiaBautizado->Municipio->Departamento->nom_departamento); ?> el 
			<?php echo e($diaBautizoEsposo); ?> de 
			<?php echo e($mesPartidaBautizoEsposo); ?> de 
			<?php echo e($yearBautizoEsposo); ?>. Lib: 
			<?php echo e($datos->esposo_lib_baut); ?> Fol: 
			<?php echo e($datos->esposo_fol_baut); ?> Partida N°: 
			<?php echo e($datos->esposo_par_baut); ?>. Con: 
			<?php echo e($datos->esposa); ?>, hija de 
			<?php echo e($padresEsposa); ?>, bautizada en la 
			<?php echo e($datos->ParroquiaBautizada->nombre); ?> de 
			<?php echo e($datos->ParroquiaBautizada->Municipio->nom_municipio); ?> - 
			<?php echo e($datos->ParroquiaBautizada->Municipio->Departamento->nom_departamento); ?> el 
			<?php echo e($diaBautizoEsposa); ?> de 
			<?php echo e($mesPartidaBautizoEsposa); ?> de 
			<?php echo e($yearBautizoEsposa); ?>. Lib: <?php echo e($datos->esposa_lib_baut); ?> Fol: <?php echo e($datos->esposa_fol_baut); ?> Partida N°: <?php echo e($datos->esposa_par_baut); ?>. Testigos: <?php echo e($testigos); ?>.
		</div>
		<div class="justify-text">
			<div>
				<strong>Doy fe:</strong> <?php echo e($datos->Parroco->Celebrante->nom_celebrante); ?> - <?php echo e($datos->Parroco->Celebrante->cod_cargo_cel); ?>

			</div>
		</div>
		<?php if(count($anotacion)>0): ?>
		<p>
			<?php $__currentLoopData = $anotacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<strong>Anotación:</strong> <?php echo e($anot->anotacion); ?><br>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</p>
		<?php endif; ?>
		<p>Es fiel copia expedida en Fusagasugá, Cundinamarca a los <?php echo e($dhoy); ?> dias del mes de <?php echo e($mhoy); ?> de <?php echo e($yhoy); ?></p>
		<div id="firma">
			<p><strong><?php echo e($firma->celebrante->nom_celebrante); ?><br>
			<?php echo e($firma->cargo); ?></strong></p>
		</div>
	</body>
</html>
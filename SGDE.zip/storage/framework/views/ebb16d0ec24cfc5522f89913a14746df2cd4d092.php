<?php $__env->startSection('title','Bautismos'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="container" id="app">
	<div class="block-header">
		<h2>Crear Bautismo</h2>
	</div>
	<div class="card">
		<div class="card-header">
			<h2>Crear bautismo
			<small>Se registrara una nueva persona bautizada y se asignara automaticamente sin libro, folio o partida</small>
			</h2>
			<input type="" id="data" value="<?php echo e($bautismo); ?>" hidden="true">
			<input type="" id="tipoEdicion" value="<?php echo e($tipo); ?>" hidden="true">
		</div>
		<div class="card-body card-padding">
			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-12">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="nombreBautisado" v-model="bautizado.nombre">
							<label class="fg-label">Nombre del bautizado</label>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-6 col-lg-6">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="nombrePadre" v-model="bautizado.padre">
							<label class="fg-label">Nombre del padre</label>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-6 col-lg-6">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="nombreMadre" v-model="bautizado.madre">
							<label class="fg-label">Nombre de la madre</label>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-6 col-lg-6">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="nombreAbueloPaterno" v-model="bautizado.abueloPaterno">
							<label class="fg-label">Nombre del abuelo paterno</label>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-6 col-lg-6">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="nombreAbuelaPaterna" v-model="bautizado.abuelaPaterna">
							<label class="fg-label">Nombre de la abuela paterna</label>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-6 col-lg-6">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="nombreAbueloMaterno" v-model="bautizado.abueloMaterno">
							<label class="fg-label">Nombre del abuelo materno</label>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-6 col-lg-6">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="nombreAbuelaMaterna" v-model="bautizado.abuelaMaterna">
							<label class="fg-label">Nombre de la abuela materna</label>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-6 col-lg-6">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="nombrePadrino" v-model="bautizado.padrino">
							<label class="fg-label">Nombre del padrino</label>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-6 col-lg-6">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="nombreMadrina" v-model="bautizado.madrina">
							<label class="fg-label">Nombre de la madrina</label>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-12">
					<label>Genero</label>
					<select class="chosen" data-placeholder="Seleccione un genero..."  id="genero" v-model="bautizado.genero">
						<?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($genero); ?>"><?php echo e($genero); ?></option>	
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-6 col-lg-6">
					<label>Fecha de nacimiento</label>
					<div class="input-group form-group">
						<span class="input-group-addon"><i class="zmdi zmdi-calendar"></i></span>
						<div class="dtp-container">
							<input type='text' class="form-control date-picker"
							placeholder="Click here..."  id="fechaNacimiento" v-model="bautizado.fechaNacimiento">
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-6 col-lg-6">
					<label>Ciudad de nacimiento</label>
					<select class="chosen" data-placeholder="Seleccione una ciudad..."  id="ciudadNacimiento" v-model="bautizado.ciudadNacimiento">
						<?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($municipio->id); ?>"><?php echo e($municipio->nom_municipio); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<div class="row m-b-25">
				<div class="col-sm-12 col-md-6 col-lg-6">
					<label>Fecha de bautismo</label>
					<div class="input-group form-group">
						<span class="input-group-addon"><i class="zmdi zmdi-calendar"></i></span>
						<div class="dtp-container">
							<input type='text' class="form-control date-picker"
							placeholder="Click here..."  id="fechaBautismo" v-model="bautizado.fechaBautismo">
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-6 col-lg-6">
					<label>Celebrante</label>
					<select class="chosen" data-placeholder="Seleccione un celebrante..."  id="celebrante" v-model="bautizado.celebrante">
						<?php $__currentLoopData = $celebrantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $celebrante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($celebrante->id); ?>"><?php echo e($celebrante->nom_celebrante); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-4 col-lg-4">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="libro" v-model="bautizado.libro">
							<label class="fg-label">Libro</label>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-4 col-lg-4">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="folio" v-model="bautizado.folio">
							<label class="fg-label">Folio</label>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-4 col-lg-4">
					<div class="form-group fg-float">
						<div class="fg-line fg-toggled">
							<input type="text" class="form-control fg-input" id="partida" v-model="bautizado.partida">
							<label class="fg-label">Partida</label>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="card-header">
			<h2>Anotaciones
			</h2>
		</div>
		<div class="card-body card-padding">
			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-12" v-for="(anotacion,index) in bautizado.anotaciones ">
					<div class="card-header">
						<h2><small>Anotacion #{{index+1}}</small></h2>
						<ul class="actions">
							<li>
								<a v-on:click="eliminarAnotacion(anotacion,index)">
									<i class="zmdi zmdi-tag-close"></i>
								</a>
							</li>
						</ul>
					</div>
					<div class="card-body card-padding">
						{{ anotacion.Anotacion }}
					</div>
				</div>
			</div>
			<div class="row" v-show="tipoEdicion=='true'">
				<div class="col-sm-12 col-md-12 col-lg-12">
					<p class="c-black f-500 m-t-20 m-b-20">Nueva anotacion</p>
					<div class="form-group">
						<div class="fg-line">
							<textarea class="form-control"
							placeholder="Decreto ó anotacion" v-model="bautizado.anotacion"></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-12">
					<button type="submit" id="btnEnviar" class="btn btn-primary" v-on:click="guardar">Editar</button>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('views/administracion/bautismoeditar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>